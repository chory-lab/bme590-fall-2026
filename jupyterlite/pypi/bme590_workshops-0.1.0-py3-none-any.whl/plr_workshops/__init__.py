"""bme590-workshops: the PyLabRobot browser glue.

Only what a JupyterLite kernel needs: the transport abstraction, InlineVisualizer,
and the JupyterLite bridge (patch_visualizer). The host-side build tools and the
old hand-rolled demo are deliberately excluded from this wheel.
"""

from .inline import InlineVisualizer
from .jupyterlite_bridge import BrowserVisualizer, JupyterLiteBridgeTransport, patch_visualizer
from .transport import VisualizerTransport

__all__ = [
  "BrowserVisualizer",
  "InlineVisualizer",
  "JupyterLiteBridgeTransport",
  "VisualizerTransport",
  "patch_visualizer",
]

"""bme590-workshops: the PyLabRobot browser glue.

Only what a JupyterLite kernel needs. Import submodules explicitly::

    from plr_workshops.inline import InlineVisualizer
    from plr_workshops.jupyterlite_bridge import patch_visualizer

This namespace stays importable with no side effects (no eager pylabrobot
import), which is what makes it safe in the browser.
"""

__version__ = "0.1.0"
